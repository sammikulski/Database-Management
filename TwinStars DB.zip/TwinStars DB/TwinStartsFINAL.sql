CREATE TABLE customer_t(
	customer_id integer(10) NOT NULL, 
    street_address_line_1 varchar (30),
    street_address_line_2 varchar (30),
    city varchar(20),
    state varchar(2),
    zip integer(5),
CONSTRAINT customer_tPK PRIMARY KEY (customer_id)
);

CREATE TABLE product_t(
	product_id integer (10) NOT NULL,
    product_name varchar (30) NOT NULL,
    percentage_recycled integer(2) NOT NULL,
    price decimal(10,2),
CONSTRAINT product_tPK PRIMARY KEY (product_id)
);

CREATE TABLE order_t(
	order_id		integer(10)			NOT NULL,
	customer_id		integer(10)			NOT NULL,
	order_date		date,		
CONSTRAINT order_tPK PRIMARY KEY (order_id),
CONSTRAINT order_tFK FOREIGN KEY (customer_id) REFERENCES customer_t(customer_id)
);

CREATE TABLE invoice_t(
Invoice_id integer(10) NOT NULL,
customer_id integer(10) NOT NULL,
order_id integer(10) NOT NULL,
amount_due integer(10) NOT NULL,
payment_method varchar(20) NOT NULL,
CONSTRAINT invoice_tPK PRIMARY KEY (Invoice_ID),
CONSTRAINT invoice_tFK1 FOREIGN KEY (customer_id) REFERENCES customer_t(customer_id),
CONSTRAINT invoice_tFK2 FOREIGN KEY (order_id) REFERENCES order_t(order_id)
);


CREATE TABLE donation_type( 
	donation_id  integer(10) NOT NULL, 
    donation_type varchar (20) NOT NULL,
    cash boolean,
    hardware boolean,
    donation_date date NOT NULL,
CONSTRAINT donation_tPK PRIMARY KEY (donation_id)
);

CREATE TABLE donor_t( 
	donation_id  integer(10) NOT NULL ,
	donor_name varchar(20) NOT NULL, 
	location varchar(20) ,
CONSTRAINT donor_tPK PRIMARY KEY (donation_id),
CONSTRAINT donor_tFK FOREIGN KEY (donation_id) REFERENCES donation_type(donation_id)
); 

CREATE TABLE orderline_t(
	order_id 		integer(10)			NOT NULL,
	product_id		integer(10)			NOT NULL,
CONSTRAINT orderline_tPK PRIMARY KEY (order_id, product_id),
CONSTRAINT orderline_tFK1 FOREIGN KEY (order_id) REFERENCES order_t(order_id),
CONSTRAINT orderline_tFK2 FOREIGN KEY (product_Id) REFERENCES product_t(product_id)
);

CREATE TABLE recycledpart_t(
part_id integer(10) NOT NULL,
product_id integer(10) NOT NULL,
donation_id integer(10) NOT NULL,
component_name varchar(20) NOT NULL,
date_donated Date NOT NULL,
description varchar(30),
CONSTRAINT recycledpart_tPK PRIMARY KEY (part_id),
CONSTRAINT recycledpart_tFK1 FOREIGN KEY (product_id) REFERENCES product_t (product_id),
CONSTRAINT recycledpart_tFK2 FOREIGN KEY (donation_id) REFERENCES donation_type (donation_id)
);

CREATE TABLE tv_t(
	product_id		integer(10)		NOT NULL,
    screen_size 	varchar(10),
CONSTRAINT tv_tPK PRIMARY KEY (product_id),
CONSTRAINT tv_tFK FOREIGN KEY (product_id) REFERENCES product_t (product_id)
);	

CREATE TABLE mobile_t(
	product_id		integer(10)		NOT NULL,
	camera_resolution	varchar(10),
	phone_carrier		varchar(10),
CONSTRAINT product_tPK PRIMARY KEY (product_id),
CONSTRAINT product_tFK FOREIGN KEY (product_id) REFERENCES product_t(product_id)
);
CREATE TABLE pad_t(
product_id integer(10) NOT NULL,
Phone_Carrier varchar(10),
CONSTRAINT pad_tPK PRIMARY KEY (product_id),
CONSTRAINT pad_tFK FOREIGN KEY (product_id) REFERENCES product_t(product_id)
);


INSERT INTO customer_t values (3002, '1574 Ashcraft Court', null, 'Philadelphia', 'PA', 19101);
INSERT INTO customer_t values (3003, '8 Cambridge Drive',null,'Philadelphia','PA',19122);
INSERT INTO customer_t values (3004,'12 Wally Court',null,'Philadelphia','PA',19161);

INSERT INTO product_t values(2002,'SuperNova TV',35,1500);
INSERT INTO product_t values(2003,'Aurora Phone',45,800);
INSERT INTO product_t values(2004,'NebulaReach',75,400);

INSERT INTO order_t values(1,3002,'2016-12-16');
INSERT INTO order_t values(2,3003,'2018-04-16');
INSERT INTO order_t values(3,3004,'2018-04-20');

INSERT INTO invoice_t values (5001,3002,1,3000,'Credit');
INSERT INTO invoice_t values (5002,3003,2,4000,'Cash');
INSERT INTO invoice_t values (5003,3004,3,1000,'Credit');

INSERT INTO donation_type values (8,'screen',0,1,'2016-12-22');
INSERT INTO donation_type values (9,'cash',1,0,'2016-01-19');
INSERT INTO donation_type values (10,'wiring',0,1,'2017-03-10');

INSERT INTO donor_t values (8,'RomanName','Philadelphia');
INSERT INTO donor_t values (9,'Cupid Arrow','Philadelphia');
INSERT INTO donor_t values (10,'Sears','Garnet Valley');

INSERT INTO orderline_t values (1,2002);
INSERT INTO orderline_t values (2,2003);
INSERT INTO orderline_t values (3,2004);

INSERT INTO recycledpart_t values (6001,2002,8,'screen','2014-12-16','from warehouse');
INSERT INTO recycledpart_t values (6002,2003,9,'wiring','2016-05-22','roman company sale');
INSERT INTO recycledpart_t values (6003,2004,10,'subwoofer','2017-02-09','church donation');

INSERT INTO tv_t values (2002,'20 x 20');
INSERT INTO mobile_t values(2003,'5.1MP','at&t');
INSERT INTO pad_t values (2004, 'verizon');


create unique index customers
on customer_t (customer_id);
create unique index products
on product_t (product_id);
create unique index orders
on order_t (order_id);






	


    