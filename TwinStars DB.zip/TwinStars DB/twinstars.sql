CREATE TABLE customer_t(
	customer_id integer(10) NOT NULL, 
    street_address_line_1 varchar (30),
    street_address_line_2 varchar (30),
    city varchar(20),
    state varchar(2),
    zip integer(5),
CONSTRAINT customer_tPK PRIMARY KEY (customer_id)
);

CREATE TABLE product_t(
	product_id integer (10) NOT NULL,
    product_name varchar (30) NOT NULL,
    percentage_recycled integer(2) NOT NULL,
    price decimal(10,2),
CONSTRAINT product_tPK PRIMARY KEY (product_id)
);
CREATE TABLE order_t(
	order_id		integer(10)			NOT NULL,
	customer_id		integer(10)			NOT NULL,
	order_date		date,		
CONSTRAINT order_tPK PRIMARY KEY (order_id),
CONSTRAINT order_tFK FOREIGN KEY (customer_id) REFERENCES customer_t(customer_id)
);

CREATE TABLE invoice_t(
Invoice_ID integer(10) NOT NULL,
Customer_ID integer(10) NOT NULL,
Order_ID integer(10) NOT NULL,
Amount_Due integer(10) NOT NULL,
Payment_Method varchar(20) NOT NULL,
CONSTRAINT invoice_tPK PRIMARY KEY (Invoice_ID),
CONSTRAINT invoice_tFK1 FOREIGN KEY (customer_id) REFERENCES customer_t(customer_id),
CONSTRAINT invoice_tFK2 FOREIGN KEY (order_id) REFERENCES order_t(order_id)

);
CREATE TABLE donor_t( 
	donation_id  integer(10) NOT NULL ,
	donor_name varchar(20) NOT NULL, 
	location varchar(20) ,
CONSTRAINT donor_tPK PRIMARY KEY (donation_id)
); 

CREATE TABLE orderline_t(
	order_id 		integer(10)			NOT NULL,
	product_id		integer(10)			NOT NULL,
	qty_ordered		integer(5),
CONSTRAINT orderline_tPK PRIMARY KEY (order_id, product_id),
CONSTRAINT orderline_tFK1 FOREIGN KEY (order_id) REFERENCES order_t(order_id),
CONSTRAINT orderline_tFK2 FOREIGN KEY (product_Id) REFERENCES product_t(product_id)
);

CREATE TABLE donationtype_t( 
	donation_id  integer(10) NOT NULL ,
	donation_type varchar(20)NOT NULL,
    donation_key integer(10) NOT NULL,
CONSTRAINT donor_tPK PRIMARY KEY (donation_key),
CONSTRAINT donor_tFK1 FOREIGN KEY (donation_id) REFERENCES donor_t(donation_id)
);
 

CREATE TABLE recycledpart_t(
part_id integer(10) NOT NULL,
product_id integer(10) NOT NULL,
donation_key integer(10) NOT NULL,
component_name varchar(20) NOT NULL,
date_donated Date NOT NULL,
description varchar(30),
CONSTRAINT recycledpart_tPK PRIMARY KEY (part_id),
CONSTRAINT recycledpart_tFK1 FOREIGN KEY (product_id) REFERENCES product_t(product_id),
CONSTRAINT recycledpart_tFK2 FOREIGN KEY (donation_key) REFERENCES donationtype_t(donation_key)
);

CREATE TABLE tv_t(
	product_id		integer(10)		NOT NULL,
CONSTRAINT tv_tPK PRIMARY KEY (product_id),
CONSTRAINT tv_tFK FOREIGN KEY (product_id) REFERENCES product_t (product_id)
);	



CREATE TABLE mobile_t(
	product_id		integer(10)		NOT NULL,
	camera_resolution	varchar(10),
	phone_carrier		varchar(10),
CONSTRAINT product_tPK PRIMARY KEY (product_id),
CONSTRAINT product_tFK FOREIGN KEY (product_id) REFERENCES product_t(product_id)
);
CREATE TABLE pad_t(
product_id integer(10) NOT NULL,
Phone_Carrier varchar(10),
CONSTRAINT pad_tPK PRIMARY KEY (product_id),
CONSTRAINT pad_tFK FOREIGN KEY (product_id) REFERENCES product_t(product_id)
);
 CREATE TABLE donationParts_t( 
	donation_id  integer(10) NOT NULL, 
	part_id  integer(10) NOT NULL, 
CONSTRAINT donationParts_tPK PRIMARY KEY (donation_id, part_id), 
CONSTRAINT donationParts_tFK FOREIGN KEY (part_id) REFERENCES recycledpart_t(part_id) 
);  








	


    